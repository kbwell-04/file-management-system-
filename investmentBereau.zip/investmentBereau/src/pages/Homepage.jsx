//import React from "react"; 
import { useNavigate } from "react-router-dom";
import './AuthStyles.css';

const HomePage = () => {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate("/login");
  };

  return (
    <div className="homepage">
      <div className="header">
        <h1 className="welcome-text">Welcome to File Management System</h1>
        <button onClick={handleLogin} className="login-button">Login</button>
      </div>
    </div>
  );
};

export default HomePage;

import React, { useState } from 'react';
import { db } from "../firebaseConfig"; 
import { collection, addDoc } from "firebase/firestore"; 
import { auth } from "../firebaseConfig"; 
import axios from "axios";

const FileUpload = ({ folders }) => {
  const [newFile, setNewFile] = useState(null);
  const [selectedFolderId, setSelectedFolderId] = useState("");
  const [fileSuccessMessage, setFileSuccessMessage] = useState("");
  const [fileErrorMessage, setFileErrorMessage] = useState("");

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    setNewFile(file);
  };

  const handleSubmitFile = async () => {
    if (newFile && selectedFolderId) {
      try {
        // Step 1: Upload the file to the local server
        const formData = new FormData();
        formData.append("file", newFile);

        const serverResponse = await axios.post("http://localhost:5001/upload", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });

        if (serverResponse.status === 200) {
          // Step 2: Save metadata in Firestore
          await addDoc(collection(db, "files"), {
            filename: newFile.name,
            uploadedBy: auth.currentUser.uid,
            folderId: selectedFolderId,
            uploadedAt: new Date(),
            serverPath: `/uploads/${newFile.name}`, // Store server file path for reference
          });

          setFileSuccessMessage("File uploaded and metadata saved successfully!");
        }

        setNewFile(null);
        setSelectedFolderId("");

        // Clear success message after 3 seconds
        setTimeout(() => {
          setFileSuccessMessage("");
        }, 3000);
      } catch (error) {
        console.error("Error uploading file:", error);
        setFileErrorMessage("File upload failed. Please try again.");
      }
    } else {
      setFileErrorMessage("Please select a file and folder.");
    }
  };

  return (
    <div>
      <h3>Upload File:</h3>
      <select 
        value={selectedFolderId} 
        onChange={(e) => setSelectedFolderId(e.target.value)}
      >
        <option value="">Select Folder</option>
        {folders.map((folder) => (
          <option key={folder.id} value={folder.id}>
            {folder.name}
          </option>
        ))}
      </select>
      <input type="file" onChange={handleFileUpload} />
      <button onClick={handleSubmitFile}>Upload File</button>
      {fileSuccessMessage && <p style={{ color: "green" }}>{fileSuccessMessage}</p>}
      {fileErrorMessage && <p style={{ color: "red" }}>{fileErrorMessage}</p>}
    </div>
  );
};

export default FileUpload;

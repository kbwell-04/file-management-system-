import React, { useState } from "react";
import { auth, db } from "../firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { addDoc, collection } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import './AuthStyles.css'; // Import the CSS styles

const RegisterPage = () => {
  const [userData, setUserData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    retypePassword: "",
    phone: "",
    department: "",
    role: "user",
    gender: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate password matching
    if (userData.password !== userData.retypePassword) {
      setError("Passwords do not match.");
      return;
    }

    // Clear previous error state
    setError("");

    try {
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, userData.email, userData.password);
      const userId = userCredential.user.uid;

      // Add user data to Firestore
      await addDoc(collection(db, "users"), {
        userId,
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email,
        phone: userData.phone,
        department: userData.department,
        role: userData.role,
        gender: userData.gender
      });

      // Navigate to admin page after successful registration
      navigate("/admin");
    } catch (err) {
      // Log error and update error state for user feedback
      console.error("Error creating user:", err);
      setError(err.code ? `Error: ${err.message}` : "An unexpected error occurred.");
    }
  };

  return (
    <div className="auth-container">
      <h2>Register User</h2>
      <form onSubmit={handleSubmit}>
        <input 
          name="firstName" 
          placeholder="First Name" 
          value={userData.firstName} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="lastName" 
          placeholder="Last Name" 
          value={userData.lastName} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="email" 
          type="email" 
          placeholder="Email" 
          value={userData.email} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="password" 
          type="password" 
          placeholder="Password" 
          value={userData.password} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="retypePassword" 
          type="password" 
          placeholder="Retype Password" 
          value={userData.retypePassword} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="phone" 
          placeholder="Phone Number" 
          value={userData.phone} 
          onChange={handleChange} 
          required 
        />
        <input 
          name="department" 
          placeholder="Department" 
          value={userData.department} 
          onChange={handleChange} 
          required 
        />
        <select 
          name="role" 
          value={userData.role} 
          onChange={handleChange} 
          required
        >
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
        <select 
          name="gender" 
          value={userData.gender} 
          onChange={handleChange} 
          required
        >
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
        <button type="submit">Register User</button>
      </form>
      {error && <p className="error-message">{error}</p>}
    </div>
  );
};

export default RegisterPage;
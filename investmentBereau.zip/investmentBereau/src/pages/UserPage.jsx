import React, { useState, useEffect } from "react";
import { db } from "../firebaseConfig";
import { collection, getDocs } from "firebase/firestore";
import FolderCreation from "./FolderCreation"; // Import the FolderCreation component
import FileUpload from "./FileUplaod"; // Import the FileUpload component
import "./UserPage.css"; // CSS file for styling

const UserPage = () => {
  const [folders, setFolders] = useState([]);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch folders from Firestore
  useEffect(() => {
    const fetchFolders = async () => {
      setLoading(true);
      try {
        const folderSnapshot = await getDocs(collection(db, "folders"));
        const folderData = folderSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setFolders(folderData);
        setError(null);
      } catch (err) {
        setError("Failed to fetch folders.");
        console.error("Error fetching folders:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchFolders();
  }, []);

  return (
    <div className="userpage-container">
      <h2 className="userpage-title">User Page - Manage Folders and Files</h2>

      {/* Error message */}
      {error && <div className="error-message">{error}</div>}

      {/* Folder Creation Section */}
      <FolderCreation setFolders={setFolders} setError={setError} />

      {/* Folder List */}
      <div className="folder-list">
        <h3>Your Folders</h3>
        {loading && <p>Loading folders...</p>}
        {!loading && folders.length === 0 && <p>No folders created yet.</p>}
        <ul>
          {folders.map((folder) => (
            <li
              key={folder.id}
              className={`folder-item ${selectedFolder === folder.id ? "selected" : ""}`}
              onClick={() => setSelectedFolder(folder.id)}
            >
              {folder.name}
            </li>
          ))}
        </ul>
      </div>

      {/* File Upload Section */}
      {selectedFolder && (
        <FileUpload folders={folders} setError={setError} />
      )}
    </div>
  );
};

export default UserPage;

import { useState, useEffect } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebaseConfig";

const useAdminDataFetcher = (auth, navigate) => {
  const [users, setUsers] = useState([]);
  const [folders, setFolders] = useState([]);
  const [files, setFiles] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = auth.currentUser;

        if (!currentUser) {
          navigate("/login");
          return;
        }

        const userRef = collection(db, "users");
        const userSnapshot = await getDocs(userRef);
        const userData = userSnapshot.docs.find(doc => doc.data().userId === currentUser.uid);

        if (!userData || userData.data().role !== "admin") {
          navigate("/user");
          return;
        }

        // Fetch data from Firestore
        const usersSnapshot = await getDocs(collection(db, "users"));
        setUsers(usersSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));

        const foldersSnapshot = await getDocs(collection(db, "folders"));
        setFolders(foldersSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));

        const filesSnapshot = await getDocs(collection(db, "files"));
        setFiles(filesSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));

      } catch (err) {
        setError(err.message || "Failed to fetch data from Firestore.");
        console.error("Error fetching admin data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [auth, navigate]);

  return { users, folders, files, error, loading };
};

export default useAdminDataFetcher;

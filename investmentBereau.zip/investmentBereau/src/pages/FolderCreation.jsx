import React, { useState } from "react";
import { db } from "../firebaseConfig"; 
import { collection, addDoc } from "firebase/firestore"; 
import { auth } from "../firebaseConfig"; 

const FolderCreation = ({ setFolders, setFolderSuccessMessage }) => {
  const [newFolderName, setNewFolderName] = useState("");

  const handleCreateFolder = async () => {
    if (!newFolderName || !auth.currentUser) return; // Ensure user is authenticated

    // Get the user's email from the auth object
    const createdByEmail = auth.currentUser.email;

    try {
      await addDoc(collection(db, "folders"), {
        name: newFolderName,
        createdBy: auth.currentUser.uid, // User ID
        createdByEmail: createdByEmail,    // Email of the user
        createdAt: new Date(),
      });
      setNewFolderName("");
      setFolderSuccessMessage("Folder created successfully!");

      // Optionally, you can fetch updated folders here if needed
      // const updatedFolders = await fetchFolders(); // Uncomment if you implement this function

      setTimeout(() => {
        setFolderSuccessMessage("");
      }, 3000);
    } catch (error) {
      console.error("Error creating folder:", error);
    }
  };

  return (
    <div>
      <h3>Create Folder:</h3>
      <input 
        type="text" 
        value={newFolderName} 
        onChange={(e) => setNewFolderName(e.target.value)} 
        placeholder="Folder Name"
      />
      <button onClick={handleCreateFolder}>Create Folder</button>
    </div>
  );
};

export default FolderCreation; 
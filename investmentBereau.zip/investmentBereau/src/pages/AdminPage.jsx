import React, { useEffect, useState } from "react";
import { db } from "../firebaseConfig";
import { collection, getDocs } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebaseConfig";
import FileUpload from "./FileUplaod"; // Import the FileUpload component
import FolderCreation from "./FolderCreation"; // Import the FolderCreation component

const AdminPage = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [folders, setFolders] = useState([]);
  const [files, setFiles] = useState([]);
  const [folderSuccessMessage, setFolderSuccessMessage] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        navigate("/login");
        return;
      }

      try {
        // Authenticate admin user
        const userRef = collection(db, "users");
        const userSnapshot = await getDocs(userRef);
        const currentUserData = userSnapshot.docs.find(
          (doc) => doc.data().userId === currentUser.uid
        );

        if (!currentUserData || currentUserData.data().role !== "admin") {
          navigate("/user");
          return;
        }

        // Fetch all users
        const usersSnapshot = await getDocs(collection(db, "users"));
        const usersList = usersSnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setUsers(usersList);

        // Fetch folders
        const foldersSnapshot = await getDocs(collection(db, "folders"));
        const foldersList = foldersSnapshot.docs.map((doc) => {
          const folderData = doc.data();
          const creator = usersList.find(
            (user) => user.userId === folderData.createdBy
          );
          return {
            id: doc.id,
            name: folderData.name || "N/A",
            createdBy: creator ? creator.email : "Unknown",
          };
        });
        setFolders(foldersList);

        // Fetch files and resolve "uploadedBy" and "folderName"
        const filesSnapshot = await getDocs(collection(db, "files"));
        const filesList = filesSnapshot.docs.map((doc) => {
          const fileData = doc.data();
          const folder = foldersList.find(
            (folder) => folder.id === fileData.folderId
          );
          const uploader = usersList.find(
            (user) => user.userId === fileData.uploadedBy
          );
          return {
            filename: fileData.filename || "Unnamed File",
            folderName: folder ? folder.name : "Unknown Folder",
            uploadedBy: uploader ? uploader.email : "Unknown User",
          };
        });
        setFiles(filesList);
      } catch (error) {
        console.error("Error fetching data from Firestore:", error);
      }
    };

    fetchData();
  }, [navigate]);

  const handleRegister = () => {
    navigate("/register");
  };

  return (
    <div className="admin-page-container">
      <div className="sidebar">
        {/* Folder Creation Section */}
        <FolderCreation
          setFolders={setFolders}
          setFolderSuccessMessage={setFolderSuccessMessage}
        />
        {folderSuccessMessage && (
          <p className="success-message">{folderSuccessMessage}</p>
        )}

        {/* File Upload Section */}
        <FileUpload folders={folders} />
      </div>

      <div className="main-content">
        {/* Add User Section */}
        <div className="add-user-section">
          <h3>Add User</h3>
          <button onClick={handleRegister} className="register-button">
            Register User
          </button>
        </div>

        {/* Registered Users Table */}
        <h3>Registered Users:</h3>
        <div className="table-container">
          <table className="styled-table">
            <thead>
              <tr>
                <th>User ID</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? (
                users.map((user) => (
                  <tr key={user.id}>
                    <td>{user.userId || "N/A"}</td>
                    <td>{user.email || "N/A"}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="2">No registered users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Folders Created Table */}
        <h3>Folders Created:</h3>
        <div className="table-container">
          <table className="styled-table">
            <thead>
              <tr>
                <th>Folder Name</th>
                <th>Created By</th>
              </tr>
            </thead>
            <tbody>
              {folders.length > 0 ? (
                folders.map((folder) => (
                  <tr key={folder.id}>
                    <td>{folder.name}</td>
                    <td>{folder.createdBy}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="2">No folders created.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Files Uploaded Table */}
        <h3>Uploaded Files:</h3>
        <div className="table-container">
          <table className="styled-table">
            <thead>
              <tr>
                <th>Filename</th>
                <th>Folder Name</th>
                <th>Uploaded By</th>
              </tr>
            </thead>
            <tbody>
              {files.length > 0 ? (
                files.map((file, index) => (
                  <tr key={index}>
                    <td>{file.filename}</td>
                    <td>{file.folderName}</td>
                    <td>{file.uploadedBy}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="3">No files uploaded.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <style>{`
        .admin-page-container {
          display: flex;
          font-family: Arial, sans-serif;
          padding: 20px;
          background-color: #f9f9f9;
        }
        .sidebar {
          flex: 0 0 30%;
          margin-right: 20px;
          padding: 10px;
          background-color: #ffffff;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .main-content {
          flex: 1;
          padding: 20px;
          background-color: #ffffff;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .add-user-section {
          margin-bottom: 20px;
        }
        .register-button {
          padding: 10px 20px;
          background-color: #007bff;
          color: white;
          border: none;
          cursor: pointer;
          font-size: 16px;
          border-radius: 5px;
          transition: background-color 0.3s ease;
        }
        .register-button:hover {
          background-color: #0056b3;
        }
        .table-container {
          margin-bottom: 30px;
        }
        .styled-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        .styled-table th, .styled-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        .styled-table th {
          background-color: #f2f2f2;
          font-weight: bold;
        }
        .styled-table tr:hover {
          background-color: #f9f9f9;
        }
        .success-message {
          color: green;
          font-weight: bold;
        }
      `}</style>
    </div>
  );
};

export default AdminPage;

const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 5001;

// Enable CORS
app.use(cors());

// Set up storage with Multer
const upload = multer({
  dest: "uploads/",
});

// Serve static files from 'uploads' directory
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// File upload endpoint
app.post("/upload", upload.single("file"), (req, res) => {
  const file = req.file;
  if (!file) {
    return res.status(400).json({ message: "No file uploaded" });
  }

  // Rename file with original name
  const targetPath = path.join(__dirname, "uploads", file.originalname);
  fs.rename(file.path, targetPath, (err) => {
    if (err) {
      return res.status(500).json({ message: "File upload failed" });
    }
    res.status(200).json({ message: "File uploaded successfully", originalname: file.originalname });
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
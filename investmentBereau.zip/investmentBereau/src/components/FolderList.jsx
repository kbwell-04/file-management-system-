import React from "react";
import { FaFolder } from "react-icons/fa"; // Import folder icon from react-icons

const FolderList = ({ folders, parentId = null }) => {
  const childFolders = folders.filter((folder) => folder.parentId === parentId);

  return (
    <ul>
      {childFolders.map((folder) => (
        <li key={folder.id}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <FaFolder style={{ marginRight: "8px", color: "#ffcc00" }} />
            {folder.name}
          </div>
          {/* Recursively render subfolders */}
          <FolderList folders={folders} parentId={folder.id} />
        </li>
      ))}
    </ul>
  );
};

export default FolderList;

// src/firebaseConfig.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";
import { getFirestore } from "firebase/firestore";

// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCrd9c6BZKas8TAfOt-MbMADUlFgjnCJZY",
  authDomain: "file-management-system-f511c.firebaseapp.com",
  projectId: "file-management-system-f511c",
  storageBucket: "file-management-system-f511c.firebasestorage.app",
  messagingSenderId: "1025971907327",
  appId: "1:1025971907327:web:f11e2eacff5bdf7abc7aca"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const db = getFirestore(app);
export default app;
